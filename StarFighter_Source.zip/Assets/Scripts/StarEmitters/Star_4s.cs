﻿using UnityEngine;
using System.Collections;

public class Star_4s : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
