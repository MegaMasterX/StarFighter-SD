﻿using UnityEngine;
using System.Collections;

public class SpawnerVoiceOver2 : MonoBehaviour {

	void StartVO()
    {
        audio.PlayDelayed(4.0f);

    }
}
