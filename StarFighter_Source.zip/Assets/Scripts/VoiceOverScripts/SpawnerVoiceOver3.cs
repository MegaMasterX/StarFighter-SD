﻿using UnityEngine;
using System.Collections;

public class SpawnerVoiceOver3 : MonoBehaviour {

	void StartVO()
    {
        audio.PlayDelayed(4.0F);

    }
	
}
