﻿using UnityEngine;
using System.Collections;

public class Voice_Victory : MonoBehaviour {

	void StartVO()
    {
        audio.Play();
        
    }
}
