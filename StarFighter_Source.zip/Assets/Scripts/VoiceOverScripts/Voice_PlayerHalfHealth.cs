﻿using UnityEngine;
using System.Collections;

public class Voice_PlayerHalfHealth : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
